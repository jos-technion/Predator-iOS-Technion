//
//  PointTest.h
//  Predator
//
//  Created by admin on 11/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//
#include "TldImage.h"


class PointTest {
public:
    PointTest(float x0, float y0, float x1, float y1);
    int test(TldImage *img, int patchX, int patchY, int patchW, int patchH);
private:
    float x0;
    float y0;
    float x1;
    float y1;
    int width;
    int height;
};