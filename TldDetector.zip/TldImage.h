//
//  TldImage.h
//  majd marian
//
//  Created by admin on 10/15/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#pragma once
#include <algorithm>

class TldImage {
    // Private ===============================================================
private:
   
    
    // Dimensions of the image
    int width, height;
    
    
    // Public ================================================================
public:
    
    unsigned char *planar_data;//for one range array
    /*  Constructor. */
    TldImage(void);
    
    /* Creates the image from unsigned char* data */
    void createFromImage( unsigned char*, int width, int height);
    
    /*  Instantiates this instance containing the contents of the bounding-box
     in the given image instance warped by the given matrix.
     image: image to create warp from
     bb: bounding-box [x, y, width, height]
     m: 2x2 transformation matrix (translation is added inside) */
    void createWarp(TldImage *image, double *bb, float *m);
    
    
    /*  Getter for width. */
    int getWidth(void);
    
    /*  Getter for height. */
    int getHeight(void);
    
    /*  Returns the data field of this instance. */
    unsigned char *getData(void);
    
    /*  Destructor. */
    ~TldImage(void);
    
    
    // Protected =============================================================
protected:
    /*  Sets the data field by reference, i.e. the array is not copied.
     d: data to set */
    void setData(unsigned char *d);
    
    
};
